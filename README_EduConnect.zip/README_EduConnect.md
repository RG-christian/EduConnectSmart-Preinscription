
# 📘 EduConnect Smart – Système de Gestion de la Scolarité

EduConnect Smart est une application web complète destinée à la gestion académique d’un établissement scolaire.  
Elle permet la préinscription, la connexion sécurisée, la gestion des étudiants et la génération automatique de documents au format PDF.  
Ce projet est basé sur **Vue.js (frontend)** et **Node.js/Express avec Prisma (backend)**, en utilisant **MySQL** comme base de données.

---

## 🏗️ Structure du projet

```
Projet-SGS-EduConnect Smart/
├── backend/           # API Express (Node.js + Prisma)
├── frontend/          # Application Vue.js (Vite + Tailwind CSS)
├── render.yaml        # Fichier de déploiement Render (optionnel)
├── tsconfig.json      # Config TypeScript globale
```

---

## ⚙️ Prérequis

- Node.js (v18+ recommandé)
- npm
- MySQL (port 3308 dans ce projet)
- Un éditeur comme VS Code

---

## 🔐 Configuration de la base de données

1. Démarrer votre serveur MySQL local
2. Créer une base de données nommée `educonnect`
3. Assurez-vous que le port utilisé est bien **3308**

### Exemple de connexion MySQL locale :

```sql
CREATE DATABASE educonnect;
```

---

## 🔧 Variables d'environnement `.env` (backend)

Créez un fichier `.env` dans le dossier `backend/` :

```
PORT=4000
DATABASE_URL="mysql://root:<motdepasse>@localhost:3308/educonnect"
```

> Remplace `<motdepasse>` par celui de ton MySQL local.  
> Si tu n'as pas défini de mot de passe : utilise `"mysql://root@localhost:3308/educonnect"`

---

## ▶️ Lancement du backend

```bash
cd backend

# 1. Installer les dépendances
npm install

# 2. Générer le client Prisma
npx prisma generate

# 3. (optionnel) Synchroniser le schéma avec la base si elle est vide
npx prisma db push

# 4. Lancer le serveur
npm run dev
```

> Le backend écoute sur `http://localhost:4000`

---

## ▶️ Lancement du frontend

```bash
cd frontend

# 1. Installer les dépendances
npm install

# 2. Lancer le serveur de développement Vite
npm run dev
```

> Le frontend est accessible sur `http://localhost:5173`

---

## 🔁 Connexion API ↔️ Frontend

Dans le frontend, assure-toi que les appels Axios pointent vers :

```ts
VITE_API_BASE_URL = "http://localhost:4000/api"
```

---

## 📦 Scripts utiles (backend)

| Commande | Description |
|----------|-------------|
| `npm run dev` | Démarrer le backend en mode développement |
| `npx prisma generate` | Génère le client Prisma |
| `npx prisma db push` | Applique les modèles Prisma sur la BDD |
| `npx ts-node prisma/seed.ts` | Exécute un fichier de seed (facultatif) |

---

## 📝 Fonctionnalités du projet

- Authentification simple (admin & étudiant)
- Formulaire de préinscription
- Tableau de bord selon le rôle
- Génération de documents PDF
- Connexion sécurisée à la base MySQL
- Architecture propre en TypeScript
- Design responsive avec Tailwind CSS

---

## 🚀 À venir

- Gestion des inscriptions & réinscriptions
- Paiement en ligne
- Notifications email
- Sécurité renforcée (JWT, bcrypt)
- Déploiement final (Render / Vercel)

---

## 👨‍💻 Auteurs

- Georges Christian RAPONTCHOMBO
- Odette Fidèle Gossi LOKOSSOU

Encadré par : Dr (MC) KOUSSOUBE

---

## 🧠 Remarques

Si vous avez une erreur d’authentification :
- Vérifiez les identifiants dans la base `administrateur` ou `etudiant`
- Assurez-vous que la base `educonnect` est bien connectée via Prisma

